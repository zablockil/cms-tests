#!/bin/bash
################################################################################
#
# Generates test keys and certificates.
#
# tested on Kali Linux 2023.2 [OpenSSL 3.0.8 7 Feb 2023]
#
# Steps to reproduce:
#
# 1) download:
#    https://old.kali.org/kali-images/
#    * kali-linux-2023.2-live-amd64.iso.torrent
#
# 2) download:
#    https://debian.pkgs.org/12/debian-main-amd64/libfaketime_0.9.10-2.1_amd64.deb.html
#    https://debian.pkgs.org/12/debian-main-amd64/faketime_0.9.10-2.1_amd64.deb.html
#
# 3) install:
#    $ sudo apt install ./libfaketime...deb
#    $ sudo apt install ./faketime...deb
#
# 4) RUN:
#    $ ./generates_test_keys.sh
#
# 5) Check the expiration dates of the certificates. There should be:
#    Validity
#        Not Before: Jan  1 12:00:00 2024 GMT
#        Not After : Dec 31 12:00:00 3023 GMT
#
# 6) Each time you run script, the keys should be the same.
#
# 7) Every time you run script, the certificates (except rsassaPss /
#    / Carlo / user_RSA2048_4.cer) should be the same.
#
# X) If you don't want to use "faketime", find and replace:
#    [faketime "${date_base}" ] ==> []
#
################################################################################

date_base="2024-01-01 12:00:00"

# for "Rebex Tiny Web Server"
my_ca_website="http://localhost:1180"

custom_days () {
faketime "${date_base}" echo "$(($(($(date +%s -d "1000 years") - $(date +%s)))/$((60*60*24))))"
}
custom_days2 () {
faketime "${date_base}" echo "$(($(($(date +%s -d "1000 years - 1 day") - $(date +%s)))/$((60*60*24))))"
}

user_usage_period_days="$(custom_days2)"
root_usage_period_days="$(custom_days)"

user_alias="users"

mkdir "public_${user_alias}"
mkdir "private"
mkdir "private/${user_alias}"


################
#
# ROOT/Issuer
#
################

mkdir "private/root"
openssl version -a > "private/root/openssl_version.txt"

# https://datatracker.ietf.org/doc/html/rfc9216#section-3.2
cat <<"EOF" | openssl pkey > "private/root/key_root.pem"
-----BEGIN PRIVATE KEY-----
MIIE+wIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC2GGPTEFVNdi0L
siQ79A0Mz2G+LRJlbX2vNo8STibAnyQ9VzFrGJHjUhRX/OmrOP3rDCB2SYfBPVwd
0CdC6z9qfJkcVxDc1hK+VS9vKncL0IPUYlkJwWuMpXa1Ielz+zCuV+gjV83Uvn6w
Tn39MCmymu7nFPzihcuOnbMYOCdMmUbi1Dm8TX9P6itFR3hiIHpSKMbkoXlM1837
WaFfx57kBIoIuNjKEyPIuK9wGUAeppc5QAHJg95PPEHNHlmMyhBzClmgkyozRSeS
rkxq9XeJKU94lWGaZ0zb4karCur/eiMoCk3YNV8L3styvcMG1qUDCAaKx6FZEf7h
E9RN6L3bAgMBAAECggEAE3tFhsm7DpgDlro+1Sk1kjbHssR4sOBHb4zrPp6c18PO
6T8gWuBcj1DzOzykNTzaMaDxAia4vuxVJB1mberkNHzTFqyb8bx3ceSEOCT3aoyq
5fiFpR0L6Ba1vgg8RTvNCAIApHNa4pVk0XD8Wq+h7mlUAOYGbie5UO8/P2qWjcOz
+zcheyYXJS/iuu0t2/F0ihEWGcXBmoc8D++n7mKst2jkAHD4wlPN2MgVqnmagpBz
gobFNmCZyZpDS+PPTtQZ1XvdGF5Sodc+Fz+jpWun1kqxDHE4UIZzDA/HAaBgORbm
aEZaVsOs9ZExeqOtqu2fPB7zF/1JKdRk4UJOUxS0OQKBgQDJwonP5RwvO0sYoCiw
zuFcYTmN/hI3R3viKuxr19CH6+mvuIU85ooIHF6TiouZwhk+6+Vk7rcXdS554DT4
2RbVrX/5i/MOzx8c8IIwoZJIasLz+vx8F4n6hyhV65bXN7AIBojMh2dt8tP2MZ/R
VEfsk4mNmO6yKuzyAfjJziCnCQKBgQDnDH9UYUIPkq0PSvViKQFJFCB9BJPFhld2
pIgoziw/JZzM3W3IWU0KWG7UxS0T3xmn3IX6xmWW4vX1/088ybObZWYP0edb61GM
I9DoI5igndLgDwyOL2PFuZh5pqqc09DE+cpJW4nNoudqTNmCrjhmxNCGKgGjlD8z
/OkSccvywwKBgDd0ReajRUziEjDxjF2UbzKx8lzJsX4KIs22GIdHqSRCvlcy80Qa
5WN3ULNiyB350HCP69wDFMXYym5rJoQjPvh6GIuhYKv4V8fffxkYv5kx5uWiXZVJ
7v2x+m8rMqlyv+pkyWLV8KKytHmdiBzD+oTWxF7r4ueLjtaxngzxn93pAoGBAKpR
rR9PnroKHubSE/drUNZFLvnZwPDv6lO8T978tONL372pUT9KjR8eN31DaMpoQOpc
BqvpSoQjBLt1nDysV2krI0RwMIOzAWc0E9C8RMvJ6+RdU50Q1BSyjvLGaKi5AAHk
PTk8cGYVO1BCHGlX8p3XYfw0xQaHxtuVCV8eYgCvAoGBAIZeiVhc0YTJOjUadz+0
vSOzA1arg5k2YCPCGf7z+ijM5rbMk7jrYixD6WMjTOkVLHDsVxMBpbA7GhL7TKy5
cepBH1PVwxEIl8dqN+UoeJeBpnHo/cjJ0iCR9/aMJzI+qiUo3OMDR+UH99NIddKN
i75GRVLAeW0Izgt09EMEiD9joDswOQYKKwYBBAGSCBIIATErMCkGCWCGSAFlAwQC
AgQcpcG3hHYU7WYaawUiNRQotLfwnYzMotmTAt1i6Q==
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/root/key_root.pem" > "private/root/key_root.pem.txt"

root_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/root/key_root.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"

x509v3_config_root () {
cat <<EOF
### BEGIN SMIME single-key ROOT x509v3_config

[ req ]

	distinguished_name = smime_root_dn
	x509_extensions = x509_smime_root_ext
	string_mask = utf8only
	utf8 = yes
	prompt = no

[ smime_root_dn ]

	commonName=TEST CMS/SMIME root CA

[ x509_smime_root_ext ]

	basicConstraints = critical,CA:TRUE
	keyUsage = critical,keyCertSign,cRLSign
	extendedKeyUsage = clientAuth,emailProtection
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${root_PublicKey_shake256xof32}

### END SMIME single-key ROOT x509v3_config
EOF
}

faketime "${date_base}" openssl req -new -x509 -days "${root_usage_period_days}" -sha256 -set_serial "0x1f1cdec0d9025619" -config <(echo "$(x509v3_config_root)") -key "private/root/key_root.pem" > "private/root/cert_root.crt"

{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/root/cert_root.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/root/cert_root.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/root/cert_root.crt.txt"

dummy_crl_root=$(openssl x509 -noout -serial -in "private/root/cert_root.crt" | awk -F '=' '{print $NF}')
ca_serial_number="${dummy_crl_root}"


################
#
# USERS
#
################

# https://datatracker.ietf.org/doc/html/rfc4134#appendix-B
# AlicePrivRSASign.pri
cat <<"EOF" | basenc --decode --base64 | openssl pkey > "private/${user_alias}/key_user_RSA1024.pem"
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAOCJczmN2PX16Id2OX9OsA
W7U4PeD7er3H3HdSkNBS5tEt+mhibU0m+qWCn8l+z6glEPMIC+sVCeRkTxLLvYMs/GaG8H
2bBgrL7uNAlqE/X3BQWT3166NVbZYf8Zf8mB5vhs6odAcO+sbSx0ny36VTq5mXcCpkhSjE
7zVzhXdFdfAgMBAAECgYAApAPDJ0d2NDRspoa1eUkBSy6K0shissfXSAlqi5H3NvJ11ujN
FZBgJzFHNWRNlc1nY860n1asLzduHO4Ovygt9DmQbzTYbghb1WVq2EHzE9ctOV7+M8v/Ke
QDCz0Foo+38Y6idjeweVfTLyvehwYifQRmXskbr4saw+yRRKt/IQJBAPbW4CIhTF8KcP8n
/OWzUGqd5Q+1hZbGQPqoCrSbmwxVwgEd+TeCihTI8pMOks2lZiG5PNIGv7RVMcncrcqYLd
ECQQDo3rARJQnSAlEB3oromFD1d3dhpEWTawhVlnNd9MhbEpMic4t/03B/9aSqu3T9PCJq
2jiRKoZbbBTorkye+o4vAkEAl0zwh5sXf+4bgxsUtgtqkF+GJ1Hht6B/9eSI41m5+R6b0y
l3OCJI1yKxJZi6PVlTt/oeILLIURYjdZNR56vN8QJALPAkW/qgzYUi6tBuT/pszSHTyOTx
hERIZHPXKY9+RozsFd7kUbOU5yyZLVVleyTqo2IfPmxNZ0ERO+G+6YMCgwJAWIjZoVA4hG
qrA7y730v0nG+4tCol+/bkBS9u4oiJIW9LJZ7Qq1CTyr9AcewhJcV/+wLpIZa4M83ixpXu
b41fKA==
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA1024.pem" > "private/${user_alias}/key_user_RSA1024.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9500#section-2.1
# "testRSA2048"
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_RSA2048.pem"
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAsPnoGUOnrpiSqt4XynxA+HRP7S+BSObI6qJ7fQAVSPtRkqso
tWxQYLEYzNEx5ZSHTGypibVsJylvCfuToDTfMul8b/CZjP2Ob0LdpYrNH6l5hvFE
89FU1nZQF15oVLOpUgA7wGiHuEVawrGfey92UE68mOyUVXGweJIVDdxqdMoPvNNU
l86BU02vlBiESxOuox+dWmuVV7vfYZ79Toh/LUK43YvJh+rhv4nKuF7iHjVjBd9s
B6iDjj70HFldzOQ9r8SRI+9NirupPTkF5AKNe6kUhKJ1luB7S27ZkvB3tSTT3P59
3VVJvnzOjaA1z6Cz+4+eRvcysqhrRgFlwI9TEwIDAQABAoIBAEEYiyDP29vCzx/+
dS3LqnI5BjUuJhXUnc6AWX/PCgVAO+8A+gZRgvct7PtZb0sM6P9ZcLrweomlGezI
FrL0/6xQaa8bBr/ve/a8155OgcjFo6fZEw3Dz7ra5fbSiPmu4/b/kvrg+Br1l77J
aun6uUAs1f5B9wW+vbR7tzbT/mxaUeDiBzKpe15GwcvbJtdIVMa2YErtRjc1/5B2
BGVXyvlJv0SIlcIEMsHgnAFOp1ZgQ08aDzvilLq8XVMOahAhP1O2A3X8hKdXPyrx
IVWE9bS9ptTo+eF6eNl+d7htpKGEZHUxinoQpWEBTv+iOoHsVunkEJ3vjLP3lyI/
fY0NQ1ECgYEA3RBXAjgvIys2gfU3keImF8e/TprLge1I2vbWmV2j6rZCg5r/AS0u
pii5CvJ5/T5vfJPNgPBy8B/yRDs+6PJO1GmnlhOkG9JAIPkv0RBZvR0PMBtbp6nT
Y3yo1lwamBVBfY6rc0sLTzosZh2aGoLzrHNMQFMGaauORzBFpY5lU50CgYEAzPHl
u5DI6Xgep1vr8QvCUuEesCOgJg8Yh1UqVoY/SmQh6MYAv1I9bLGwrb3WW/7kqIoD
fj0aQV5buVZI2loMomtU9KY5SFIsPV+JuUpy7/+VE01ZQM5FdY8wiYCQiVZYju9X
Wz5LxMNoz+gT7pwlLCsC4N+R8aoBk404aF1gum8CgYAJ7VTq7Zj4TFV7Soa/T1eE
k9y8a+kdoYk3BASpCHJ29M5R2KEA7YV9wrBklHTz8VzSTFTbKHEQ5W5csAhoL5Fo
qoHzFFi3Qx7MHESQb9qHyolHEMNx6QdsHUn7rlEnaTTyrXh3ifQtD6C0yTmFXUIS
CW9wKApOrnyKJ9nI0HcuZQKBgQCMtoV6e9VGX4AEfpuHvAAnMYQFgeBiYTkBKltQ
XwozhH63uMMomUmtSG87Sz1TmrXadjAhy8gsG6I0pWaN7QgBuFnzQ/HOkwTm+qKw
AsrZt4zeXNwsH7QXHEJCFnCmqw9QzEoZTrNtHJHpNboBuVnYcoueZEJrP8OnUG3r
UjmopwKBgAqB2KYYMUqAOvYcBnEfLDmyZv9BTVNHbR2lKkMYqv5LlvDaBxVfilE0
2riO4p6BaAdvzXjKeRrGNEKoHNBpOSfYCOM16NjL8hIZB1CaV3WbT5oY+jp7Mzd5
7d56RZOE+ERK2uz/7JX9VSsM/LbH9pJibd4e8mikDS9ntciqOH/3
-----END RSA PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA2048.pem" > "private/${user_alias}/key_user_RSA2048.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc8479#section-3
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_RSA2048_encrypt.pem"
-----BEGIN PRIVATE KEY-----
MIIE/gIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCpPwXwfhDsWA3q
jN2BWg1xfDjvZDVNfgTV/b95g304Aty3z13xPXAhHZ3ROW3pgPxTj9fiq7ZMy4Ua
gMpPK81v3pHX1uokC2KcGXbgbAq2Q8ClxSXgEJllRwDENufjEdV10gArt8NlIP0N
lota1kQUuI1DMsqc5DTIa35Nq4j1GW+KmLtP0kCrGq9fMGwjDbPEpSp9DTquEMHJ
o7kyJIjB+93ikLvBUTgbxr+jcnTLXuhA8rC8r+KXre4NPPNPRyefRcALLt/URvfA
rTvFOQfi3vIjNhBZL5FdC+FVAr5QnF3r2+cuDPbnczr4/rr81kzFGWrwyAgF5FWu
pFtB5IYDAgMBAAECggEAHZ88vGNsNdmRkfhWupGW4cKCuo+Y7re8Q/H2Jd/4Nin2
FKvUPuloaztiSGDbVm+vejama/Nu5FEIumNJRYMeoVJcx2DDuUxO1ZB1aIEwfMct
/DWd0/JDzuCXB0Cu5GTWLhlz0zMGHXihIdQ0DtGKt++3Ncg5gy1D+cIqqJB515/z
jYdZmb0Wqmz7H3DisuxvnhiCAOuNrjcDau80hpMA9TQlb+XKNGHIBgKpJe6lnB0P
MsS/AjDiDoEpP9GG9mv9+96rAga4Nos6avYlwWwbC6d+hHIWvWEWsmrDfcJlm2gN
tjvG8omj00t5dAt7qGhfOoNDGr5tvJVo/g96O/0I8QKBgQDdzytVRulo9aKVdAYW
/Nj04thtnRaqsTyFH+7ibEVwNIUuld/Bp6NnuGrY+K1siX8+zA9f8mKxuXXV9KK4
O89Ypw9js2BxM7VYO9Gmp6e1RY3Rrd8w7pG7/KqoPWXkuixTay9eybrJMWu3TT36
q7NheNmBHqcFmSQQuUwEmvp3MQKBgQDDVaisMJkc/sIyQh3XrlfzmMLK+GlPDucD
w5e50fHl8Q5PmTcP20zVLhTevffCqeItSyeAno94Xdzc9vZ/rt69410kJEHyBO9L
CmhtYz94wvSdRhbqf4VzAl2WU184sIYiIZDGsnGScgIYvo6v6mITjRhc8AMdYoPR
rL6xp6frcwKBgFi1+avCj6mFzD+fxqu89nyCmXLFiAI+nmjTy7PM/7yPlNB76qDG
Dil2bW1Xj+y/1R9ld6S1CVnxRbqLe+TZLuVS82m5nRHJT3b5fbD8jquGJOE+e+xT
DgA0XoCpBa6D8yRt0uVDIyxCUsVd5DL0JusN7VehzcUEaZMyuL+CyDeRAoGBAImB
qH6mq3Kc6Komnwlw4ttJ436sxr1vuTKOIyYdZBNB0Zg5PGi+MWU0zl5LDroLi3vl
FwbVGBxcvxkSBU63FHhKMQw7Ne0gii+iQQcYQdtKKpb4ezNS1+exd55WTIcExTgL
tvYZMhgsh8tRgfLWpXor7kWmdBrgeflFiOxZIL1/AoGAeBP7sdE+gzsh8jqFnVRj
7nOg+YllJAlWsf7cTH4pLIy2Eo9D+cNjhL9LK6RaAd7PSZ1adm8HfaROA2cfCm84
RI4c7Ue0G+N6LZiFvC0Bfi5SaPVAExXOty8UqjOCoZavSaXBPuNcTXZuzswcgbxI
G5/kaJNHoEcdlVsPsYWKRNKgPzA9BgorBgEEAZIIEggBMS8wLQYJYIZIAWUDBAIC
BCCK9DKMh7687DHjA7j1U37/y2qR2UcITZmjaYI7NvAUYg==
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA2048_encrypt.pem" > "private/${user_alias}/key_user_RSA2048_encrypt.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9216#section-4.4
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_RSA2048_sign.pem"
-----BEGIN PRIVATE KEY-----
MIIE+gIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCalSn6i8Gi44/o
AVAn5GnCk4PHHNjrSfWUnnelN41KImVaTC3D9zFCrS3i4Pa9ZgHyA5Qf8JW3ZmnV
z5q7M8onZm7mZjqQeb6FUH4i2GMt4jse2Dqs165ernT9O5NLFflHUjURca3ynqEB
BV4DmhnZp8eDhv3t6dXyCjNHT82S6DgCReZuTtMc1zy++MxQlqdn9WZLhOAOpeNZ
KGmVwjeVy+8FkyzC3jX/Qcm+ZLCqlLqhBwDHdZ5qDTII2PVX1X3K7/cONxhvBbaU
l/k1swdszUtjhflyFZ80RuQ3qFC6vL/PGeWy6SCf58duq/AOEksCAWlb+MD8QH9Y
j7CFSmq1AgMBAAECggEADgxoWEDDRE5yEZ+s7TMw+WH2o+3XOOrryqnsLbOyv34I
wAAUWK7qZyjd9rSDOAtBOgFhQNXYhWZlT+0iHslCIfqJMZ8wy1iFHBCIphoMSWs5
/D+idXrUef5Y23rClBxXH0g1UnSGXnpUH4ehV6p1lvZMh4OJKEoMC4cpyd1SzXrw
+VGCc1+pXv/tTW3Rb2qoWO9JoWY+Epcssrw5N8OFIFODh4QfbLN6pVTt28aQ4pf/
1KhLoapjFzXSYp/jrcNjYJ9qRdSAbZsKOJ2yZ0yqjLHDCDipFty+W0pkUZcJhsgu
Cg1Stt7tKgSvAV/nEjN8e/vA91/AACKBCNcLzEoLgQKBgQC4eTM6BDCzlusXJBK4
SRC/WwUthJZzfOk2Gmwr0DCTRYhWQSDjBfiQNboazHObVPz45qP10fOt2iPEHeX+
VWAXTNrN69M9lEzxygA3s76lAejBR3FbLWkzLYqPB3oZwSIE7CrWHTXJipFWZv+X
FG1R418fnRCUMJ4j85qem5iyqQKBgQDWhQMJu7FC02fr83qsIdLwqhiDtTpwUN3j
qfp7JoEZOxbm3TgM1xPAkrQTUgfr2ZhXGtUwsuKHyifxQEycrTkBOg0gqAfG0fnv
ybyXK6/guctHJQiy64lL39kPuvQkKB+YO60B/oF6zbyFvqanoKXjpspObN3i3yBU
X5/EOu/LLQKBgQCUVwHWeWAgSg+pgBx9jGOnPK4hOCkznRJ7qyuo37Tv+E317lFf
vYFvlYSd4CJmmiUCkZTvK3FkL7HrFo/HwSeQFQEt7aDkN8jX9bPPFv8K+UoNgkGp
LA8YVFrDQSPyadfNVYvsuXhzJLZSYGjPOGHgI5JufYLDZ4UDK/T97ekQYQKBgDDM
ORCxvXTyGiW2USVu3EkaqFDtnMmH27G6LNxuudc/dco2cFWbZ0bbGFN8yYiBCwJl
fDGDv7wb5FIgykypqtn4lpvjHUHA6hX90gShT3TTTsZ0SjJJGgZEeV/2qyq+ZdF/
Ya+ecV26BzR1Vfuzs4jBnCuS4DaHgxcuWW2N6pZRAoGAWTovk3xdtE0TZvDerxUY
l8hX+vwJGy7uZjegi4cFecSkOR4iekVxrEvEGhpNdEB2GqdLgp6Q6GPdalCG2wc4
7pojp/0inc4RtRRf3nZHaTy00bnSe/0y+t0OUbkRMtXhnViVhCcOt6BUcsHupbu2
Adub72KLk+gvASDduuatGjqgOzA5BgorBgEEAZIIEggBMSswKQYJYIZIAWUDBAIC
BBwc90hJ90RfRmxCciUfX5a3f6Bpiz6Ys/Hugge/
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA2048_sign.pem" > "private/${user_alias}/key_user_RSA2048_sign.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9216#section-4.2
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_RSA2048_4.pem"
-----BEGIN PRIVATE KEY-----
MIIE+gIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC09InoWDgWPk2a
f0+StijSNOR8K/hN8D+l078oullsk4ASvSwjsCNo7sHUa4xQUl5JO6VqY18LANwO
Rjrc9BaX4MguzsbFXBe6uFh1mVpXmFxSpUByQ+950MFz/evPgP96wV+z4TtAwW2Z
34rTiz4DxMI07XYNFUEOls/gkUP2GxzymsO2kaYWTut3SryCqeHEFbZFkB4urMk4
xrIJC3CzWruS2Q0FHbBlfkgKN5wXVgkWFfiOucfCn+IQsaqpo1d3f9jSkbtAV5w3
vzfog8919MxKI9H6l4KuElnAtJ7BtZcsl7dUy9u9COgEykRiVokFQgqQ7XNDU+r3
SeOWwks7AgMBAAECggEAFKD2DG9A1u77q3u3p2WDH3zueTtiqgaT8u8XO+jhOI/+
HzoX9eo8DIJ/b/G3brwHyfh17JFvLH1zbgsn5bghJTz3r+JcZZ5l3srqMV8t8zjI
JEHOKC3szH8gYVKWrIgBAqOt1H9Ti8J2oKk2aymqBFr3ZXpBUCTWpEz2s3FMBUUI
qCEsAJqsdEch+kt43X5kvAom7LC1DHiE6RKfhMEub/LGNHSwY4dmzhaG6p95FJ1h
s8HoURI2ReVpsTadaKd3KoYNc1lcffmwdZs/hFs7xmmwXKMmlonh1mzHqD1/BqeJ
Hc8MP4ueDdyVgIe/uVtlQ9NcRQbuokkDyDYMYV6hzQKBgQD75ahYGFGZznRKtSE3
w/2rUqTYIWxx2PQz5G58PcsTZM89Hj4aZOoLmudHbrTQHluRNcHoXEI62rs0cVPs
D7IlZOLfs+SSTeNEXxD57mjyyufpV65OcNc1mSJAmMX2jWQ8ndnOuWPcc5J6fNvT
au0a7ZBOaeKHnA8XXL3GYilM9QKBgQC35xKi7f2JmGtsYY21tfRuDUm6EjhMW6b7
GWnI9IXF8TGj15s7oDEYvqSPTJdB6PAb/tZwdbj9mB4qj176x1kB/N7GO974O8UP
/PdHkU7duyf5nRq1mrI+yGFHVsGD313rc+akYdKcC207e6IRMST1ZFoznC6qNgpi
nNTuDz4ZbwKBgA5Dd9/dKKm77gvY69Objn6oBFuUsO5VaaaSlcsFOL2VZMLCNqQJ
+NLFZ7k8xJJQVcEIOT2uE7X/csBKdoUUcnL5nnsqVZQPQwI5G937KQgugylMZLte
WmFXlX/w5qzKXtWr3ox9JPFzveSfs1bqZBi1QQmfp0skhBo/jyNvpYUNAoGAMNkw
GhcdQW87GY7QFXQ/ePwOmV49lgrCT/BwKPDKl8l5ZgvfL/ddEzWQgH/XraoyHT2T
uEuM18+QM73hfLt26RBCHGXK1CUMMzL+fAQc7sjH1YXlkleFASg4rrpcrKqoR+KB
YSiayNhAK4yrf+WN66C8VPknbA7us0L1TEbAOAECgYEAtwRiiQwk3BlqENFypyc8
0Q1pxp3U7ciHi8mni0kNcTqe57Y/2o8nY9ISnt1GffMs79YQfRXTRdEm2St6oChI
9Cv5j74LHZXkgEVFfO2Nq/uwSzTZkePk+HoPJo4WtAdokZgRAyyHl0gEae8Rl89e
yBX7dutONALjRZFTrg18CuegOzA5BgorBgEEAZIIEggBMSswKQYJYIZIAWUDBAIC
BBySyJ1DMNPY4x1P3pudD+bp/BQhQd1lpF5bQ28F
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA2048_4.pem" > "private/${user_alias}/key_user_RSA2048_4.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9500#section-2.1
# "testRSA4096"
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_RSA4096.pem"
-----BEGIN RSA PRIVATE KEY-----
MIIJKAIBAAKCAgEAs4tJYOY75qjbqJqCl47x9jJE5Vd9jPWGFtXKV1nUnMjZNsM4
qjy5sRHBSX5bUa9pLyYR5on3Z1SAwLD0w2VPQ6+F/oyK1zTgQqitoF/XZQjgC6D3
VsNEO76DPqfRANT7Nn7r1gvbZIZ3/H3rlCRNrRr47tHGWBLAPnxz9/NY6UG8ZkWP
97uXpJqYoRgH4CwaO5rTOlc64YDh/0Mq5VgMycq/q2AvMlvNoJfoe8em1040qH1g
ikP+suT/8fS452hqmEddtRpuvQgXKldBd0kkiyFVyLkG4NVA6Mso9MAK3J/kdYoa
w2SrOeThVSiYVEQVP+7GrUxTSLLjj/VQ9fpYM5eTNzDICIG/Ee7o/jhtW1EoSamD
mUOr89lyIHaXuOwkEaJhnVXKBCM8WiztxvKG2CnQ6Dcge3ZSmqJEhyEmjcAVC7ew
fnMxOnE+WJW6rzrf+mA5WMVn+FzyWx2AondWow0aUKHkaY7amhIrsKp6YPfNImyx
Flz8+cqDCmBswPsUh/JJ5eDHHIhibFcSgIHedsEjhLbUSLZ/DnEjru90qIWWA3R1
VIPykKfeZkZeInsrFzGPikkFKwFF+6KDdyvCmltYEqzO46tigXAZ5UgH8oiXEre4
8wO6X+FH+cLzQ0q3A8HZRnNDgqCjU/Tgy76iaku/Ic6eteedR1fX3gJ/IOUCAwEA
AQKCAgBq0bC7fN8gkU/2lM6jewFL14aT6CSjS6QWS+XRaHmNOhW5dhZteimERqr3
nbyY8cKjsYOu5GCUUnszqVRGOC0beP9Afb9Q4H2YSyDZrIvK6afaY08kiJI89VDC
Yzd+xjgbqRGIzI8f1LzoNMaG4b5xAf4eoCHgXm+P/Z1FZLt+M4TyV+qamjpTTUMH
fPOalMKaubd4G1PFvFc49m47+tHI8N5uCJCr5mCFbjt8AUGrETVVFRrtyBxttL7t
5gpoawAYT0VaLTq7LmgR4c3qOVMLj66o+CQ2ecnfdpeMXgFYV6ylnZ/kpi0VCa5i
av+OCt+VpOsBScq3Eu8+w9YCMopsUCG6GzW4WD2akEBVA/X6D0JMcoYj/IHT3Xv/
G/eMji69A6URLetliZhuSb0wBxrYQaPMqAdsz8eUYzCx/RwhKtPr032aTQqWlbgW
igiJMn1SbxbRVjf6nb8EsLg92LXEBS3FOLbK6ckuyXAQei8e5NR6ZcyluVluQnSR
m+fR7JDkUP5YWNwuAehOvZIH2Oog+jcUDonQENZQHyJhlxgE3nNoD+YcI1yPTmMf
8G297mZtu5r7/aO5ccMpDXve9cV4Wgcb6Urhigsu2K5nmrqmEIUoqF4xf4eomcWJ
9KitQpCmyh758U2NCnpm3HULabGcslgow+rwQiFcCarUqVToVQKCAQEA4EG98cm1
aaz16AItIRuHG18pIUGlif0PbctZR2scHaQBjdeh4Qg5MnRe88Zs9/8xPu1MsWgd
750pzD/oevetGenvNFZiycT05ucHqk6ZSWNMCGRxpVtnRsKu74dx7yGi7oq03sTC
BDxwz7qJ5esvYuoHx0vUFmdpEqlYn7PtcCiPigPRkcWKiJbosg8e3pGAztMDWfdf
SK/pfEbuWcknHnE3VUrXBVYXhI/TBBzWMEf2RiwOZuGDn2PGEtSjV/XldjVqqufG
SsC/2dZe30svNNrb32kGIMiVykTZYdoFsTYrStXarLkP9YYzXs1+HXoWAMsas3Jp
W27HcXYh276TVwKCAQEAzPVRKdO5JMg4p2zTadRunLgT/js5uvHrEBhH0x0JE1AD
qy/COUMc2m6ZCIg96KBUbjUoN9TrlctB2O7BSmbNOMIkfoKjlDkpJ7v1cKhlXg8q
wkPl+4dv0gtIdnOidy2pcMHfR6Mt6op15wlUcyKcaTyIajFtLOy/A1l7BMqeyr2j
Nm4HZIgFmyRZb1326FaX2+YqsvjMcax/dDtkEm0B8rNhJxbsp2l15RTtTXijIpC+
CoLxRBSZK9GAPa3Jg93ydtLK4aCpA/keeL48C8r1jzzpjRI6pshfZVHFcAf+R3rI
fgOLmpSsxiDeEiWBBTRKDPs3ZVBejn7IasCG9lVkIwKCAQAvfBwxN2nPb40+TD+s
E/0ewZ6e6RyZRFlhAT7tTXPNnu2pUDB5ytj5owR8D9cBCCswTOUBZ693DktMcXfT
meAwbYV2CpiuaqMExYSs/imdDYaK/GHIBruukwihtYddgDzUz9AOn5EJfpbQlYof
ghYtlqqA+8Bz4f+wsOUQI/Qx3JTQP5C/khmMZI/vLB54OE0S/kFmamflp0IES6yq
nFpJKuXxjIBNI/ak3iNraoO8A3DVWPzPsg7B0EmfsSDJPksRJaxpddxZ9chp4ueB
1pSvV2xZOQ7QIEj/ZGa3PogYBwVRukisbB9B+OGlwFNlAHXqQxdrSd2fO6zFjKMM
uaTPAoIBAFdahwkor9Q5ccwJ2eFVJP+uhPbqDyTaTrFBZ/tWeLO+epHPfRwiun1u
fdLhHmGzU8jU5xtEqFPjmWD4AXHQds8mD5/L1iQqaJwCxA0L+IgqNrMtdSvLAaGo
JW42wpvA3mKsfplttvgroyyhEVkw+zDvF8UK49kt3gtza7cTFLKcOJ/OLWBviNQi
neuVRNKpdXfHlZNJ7vjT6E6FsZUY2Ke0REgAwURo8lJ8pNdL/1uQDS81t9aoYNAI
LnwbQbPuOJTkKowXiXGkD5Sun7D3A8nU0EXL6yuCYwYv39Jr1bhpYGI06J8tlqWr
BHr/eQnay2TU/Ts1EdfxuUGmZN9AbbkCggEBANEMkY2p8m2pTf87CSQ8jMPUOQJt
5iuenzesYLvXqVLLB4SUvXN+zDplDJPELtf2SQIHrplrPNH/H01jnWHd0ecSjVY8
HBbIs52U1d5ek3/mWji4GeRp+Iw84CUh4q2p40bmob1RJ8e9sh2ixhHjX2yJ591m
oGbLIz75a60a05mUDK0FWt9cWHn4MKgIPKbWwFhYwmYDCjO/tK2DtcySny9soh5Q
KVQriuvna2lE4YY+OUc7btmtkmp9v+LHKOI8dPabsOBU8Z8UbOGeHSNrZTQwpx3E
p0riDg0UEzFmoYrfbvf+2VzEZDX/TJYjK9VkA8w5+xat8iS0/euKuvSRMb8=
-----END RSA PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_RSA4096.pem" > "private/${user_alias}/key_user_RSA4096.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9500#section-2.3
# "testECCP256"
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_prime256v1.pem"
-----BEGIN EC PRIVATE KEY-----
MHcCAQEEIObLW92AqkWunJXowVR2Z5/+yVPBaFHnEedDk5WJxk/BoAoGCCqGSM49
AwEHoUQDQgAEQiVI+I+3gv+17KN0RFLHKh5Vj71vc75eSOkyMsxFxbFsTNEMTLjV
uKFxOelIgsiZJXKZNCX0FBmrfpCkKklCcg==
-----END EC PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_prime256v1.pem" > "private/${user_alias}/key_user_prime256v1.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9500#section-2.3
# "testECCP384"
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_secp384r1.pem"
-----BEGIN EC PRIVATE KEY-----
MIGkAgEBBDDiVjMo36v2gYhga5EyQoHB1YpEVkMbCdUQs1/syfMHyhgihG+iZxNx
qagbrA41dJ2gBwYFK4EEACKhZANiAARbCQG4hSMpbrkZ1Q/6GpyzdLxNQJWGKCv+
yhGx2VrbtUc0r1cL+CtyKM8ia89MJd28/jsaOtOUMO/3Y+HWjS4VHZFyC3eVtY2m
s0Y5YTqPubWo2kjGdHEX+ZGehCTzfsg=
-----END EC PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_secp384r1.pem" > "private/${user_alias}/key_user_secp384r1.pem.txt"

# https://gitlab.com/gnutls/gnutls/-/blob/master/tests/certs/ecc384.pem
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_secp384r1_encrypt.pem"
-----BEGIN EC PRIVATE KEY-----
MIGlAgEBBDEA/0KzbcrTBhPXp+RBJxj/ghVqyTUg3E6t6OYHN4fY0lnpOReUIsBe
B0YPqkp9euowoAcGBSuBBAAioWQDYgAEBdFp7VW/awwLHqaOT6qzraO12SYSPvIX
u/4R0oBAygamgH1/0nuW/ZKNQYfmiPtnLickPpVGaRBvoTEyAq858FmuTCFE2Kft
0/En+Dpk6md6yd+7EqqztcvY2Gw4zPNw
-----END EC PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_secp384r1_encrypt.pem" > "private/${user_alias}/key_user_secp384r1_encrypt.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9500#section-2.3
# "testECCP521"
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_secp521r1.pem"
-----BEGIN EC PRIVATE KEY-----
MIHcAgEBBEIB2STcygqIf42Zdno32HTmN6Esy0d9bghmU1ZpTWi3ZV5QaWOP3ntF
yFQBPcd6NbGGVbhMlmpgIg1A+R7Z9RRYAuqgBwYFK4EEACOhgYkDgYYABAHQ/XJX
qEx0f1YldcBzhdvr8vUr6lgIPbgv3RUx2KrjzIdf8C/3+i2iYNjrYtbS9dZJJ44y
FzagYoy7swMItuYY2wD2KtIExkYDWbyBiriWG/Dw/A7FquikKBc85W8A3psVfB5c
gsZPVi/K3vxKTCj200LPPvYW/ILTO3KFySHyvzb92A==
-----END EC PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_secp521r1.pem" > "private/${user_alias}/key_user_secp521r1.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9216#section-7.2
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_ed25519.pem"
-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEILvvxL741LfX+Ep3Iyye3Cjr4JmONIVYhZPM4M9N1IHY
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_ed25519.pem" > "private/${user_alias}/key_user_ed25519.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc9216#section-7.4
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_x25519.pem"
-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VuBCIEIIH5782H/otrhLy9Dtvzt79ffsvpcVXgdUczTdUvSQsK
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_x25519.pem" > "private/${user_alias}/key_user_x25519.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc8032#section-7.4
# -----64 octets
# SECRET KEY:
genconf_ed448 () {
cat <<"EOF"
asn1 = SEQUENCE:ed448
[ ed448 ]
parameter.0 = INTEGER:0
parameter.1 = SEQUENCE:oid
parameter.2 = FORMAT:HEX,OCTWRAP,OCTETSTRING:d65df341ad13e008567688baedda8e9dcdc17dc024974ea5b4227b6530e339bff21f99e68ca6968f3cca6dfe0fb9f4fab4fa135d5542ea3f01
[ oid ]
parameter.0 = OID:1.3.101.113
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_ed448)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_ed448.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_ed448.pem" > "private/${user_alias}/key_user_ed448.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc7748.html#section-6.2
# Bob's private key, b:
genconf_x448 () {
cat <<"EOF"
asn1 = SEQUENCE:x448
[ x448 ]
parameter.0 = INTEGER:0
parameter.1 = SEQUENCE:oid
parameter.2 = FORMAT:HEX,OCTWRAP,OCTETSTRING:1c306a7ac2a0e2e0990b294470cba339e6453772b075811d8fad0d1d6927c120bb5ee8972b0d3e21374c9c921b09d1b0366f10b65173992d
[ oid ]
parameter.0 = OID:1.3.101.111
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_x448)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_x448.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_x448.pem" > "private/${user_alias}/key_user_x448.pem.txt"

# https://gitlab.com/gnutls/gnutls/-/blob/master/tests/certs/ed25519.pem
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_ed25519_2.pem"
-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEIOXDJXOU6J6XdXx4WfcyPILPYJDH5bRfm9em+DYMkllw
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_ed25519_2.pem" > "private/${user_alias}/key_user_ed25519_2.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc7748.html#section-6.1
# Bob's private key, b:
genconf_x25519 () {
cat <<"EOF"
asn1 = SEQUENCE:x25519
[ x25519 ]
parameter.0 = INTEGER:0
parameter.1 = SEQUENCE:oid
parameter.2 = FORMAT:HEX,OCTWRAP,OCTETSTRING:5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb
[ oid ]
parameter.0 = OID:1.3.101.110
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_x25519)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_x25519_2.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_x25519_2.pem" > "private/${user_alias}/key_user_x25519_2.pem.txt"

# OpenSSL 3.2.0 23 Nov 2023 :
# $ openssl genpkey -algorithm ED448
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_ed448_2.pem"
-----BEGIN PRIVATE KEY-----
MEcCAQAwBQYDK2VxBDsEOegJHatQteVpZAxjN8q+Lk434WNCAoLd8u4QynNWGtjr
vfNRKjLmptGwjE7sAa9cdrAnaHjlD6epLA==
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_ed448_2.pem" > "private/${user_alias}/key_user_ed448_2.pem.txt"

# OpenSSL 3.2.0 23 Nov 2023 :
# $ openssl genpkey -algorithm X448
cat <<"EOF" | openssl pkey > "private/${user_alias}/key_user_x448_2.pem"
-----BEGIN PRIVATE KEY-----
MEYCAQAwBQYDK2VvBDoEOOgbgqF5fiSSyhDia1DqwGJDTc/xsSrdAZKaUnd2Hw5W
mct7DgfAllPBWWSrMN/DDz9CTOl6epCL
-----END PRIVATE KEY-----
EOF
openssl pkey -text -noout -in "private/${user_alias}/key_user_x448_2.pem" > "private/${user_alias}/key_user_x448_2.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc7027.html#appendix-A.1
# the secret key of party B
# check also: $ openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:brainpoolP256r1
rfc7027_dB="55E40BC41E37E3E2AD25C3C6654511FFA8474A91A0032087593852D3E7D76BD3"
rfc7027_x_qB="8D2D688C6CF93E1160AD04CC4429117DC2C41825E1E9FCA0ADDD34E6F1B39F7B"
rfc7027_y_qB="990C57520812BE512641E47034832106BC7D3E8DD0E4C7F1136D7006547CEC6A"
genconf_brainpoolP256r1 () {
cat <<EOF
asn1 = SEQUENCE:brainpoolP256r1
[ brainpoolP256r1 ]
parameter.0 = INTEGER:1
parameter.1 = FORMAT:HEX,OCTETSTRING:${rfc7027_dB}
parameter.2 = EXPLICIT:0,OID:1.3.36.3.3.2.8.1.1.7
parameter.3 = EXPLICIT:1,FORMAT:HEX,BITSTRING:04${rfc7027_x_qB}${rfc7027_y_qB}
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_brainpoolP256r1)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_brainpoolP256r1.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_brainpoolP256r1.pem" > "private/${user_alias}/key_user_brainpoolP256r1.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc7027.html#appendix-A.2
# the secret key of party B
# check also: $ openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:brainpoolP384r1
rfc7027_dB="032640BC6003C59260F7250C3DB58CE647F98E1260ACCE4ACDA3DD869F74E01F8BA5E0324309DB6A9831497ABAC96670"
rfc7027_x_qB="4D44326F269A597A5B58BBA565DA5556ED7FD9A8A9EB76C25F46DB69D19DC8CE6AD18E404B15738B2086DF37E71D1EB4"
rfc7027_y_qB="62D692136DE56CBE93BF5FA3188EF58BC8A3A0EC6C1E151A21038A42E9185329B5B275903D192F8D4E1F32FE9CC78C48"
genconf_brainpoolP384r1 () {
cat <<EOF
asn1 = SEQUENCE:brainpoolP384r1
[ brainpoolP384r1 ]
parameter.0 = INTEGER:1
parameter.1 = FORMAT:HEX,OCTETSTRING:${rfc7027_dB}
parameter.2 = EXPLICIT:0,OID:1.3.36.3.3.2.8.1.1.11
parameter.3 = EXPLICIT:1,FORMAT:HEX,BITSTRING:04${rfc7027_x_qB}${rfc7027_y_qB}
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_brainpoolP384r1)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_brainpoolP384r1.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_brainpoolP384r1.pem" > "private/${user_alias}/key_user_brainpoolP384r1.pem.txt"

# https://datatracker.ietf.org/doc/html/rfc7027.html#appendix-A.3
# the secret key of party B
# check also: $ openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:brainpoolP512r1
rfc7027_dB="230E18E1BCC88A362FA54E4EA3902009292F7F8033624FD471B5D8ACE49D12CFABBC19963DAB8E2F1EBA00BFFB29E4D72D13F2224562F405CB80503666B25429"
rfc7027_x_qB="9D45F66DE5D67E2E6DB6E93A59CE0BB48106097FF78A081DE781CDB31FCE8CCBAAEA8DD4320C4119F1E9CD437A2EAB3731FA9668AB268D871DEDA55A5473199F"
rfc7027_y_qB="2FDC313095BCDD5FB3A91636F07A959C8E86B5636A1E930E8396049CB481961D365CC11453A06C719835475B12CB52FC3C383BCE35E27EF194512B71876285FA"
genconf_brainpoolP512r1 () {
cat <<EOF
asn1 = SEQUENCE:brainpoolP512r1
[ brainpoolP512r1 ]
parameter.0 = INTEGER:1
parameter.1 = FORMAT:HEX,OCTETSTRING:${rfc7027_dB}
parameter.2 = EXPLICIT:0,OID:1.3.36.3.3.2.8.1.1.13
parameter.3 = EXPLICIT:1,FORMAT:HEX,BITSTRING:04${rfc7027_x_qB}${rfc7027_y_qB}
EOF
}
openssl asn1parse -genconf <(echo "$(genconf_brainpoolP512r1)") -noout -out /dev/stdout | openssl pkey > "private/${user_alias}/key_user_brainpoolP512r1.pem"
openssl pkey -text -noout -in "private/${user_alias}/key_user_brainpoolP512r1.pem" > "private/${user_alias}/key_user_brainpoolP512r1.pem.txt"


x509v3_config_user () {
cat <<EOF
### BEGIN SMIME USER x509v3_config

[ req ]

	distinguished_name = smime_user_dn
	#req_extensions =
	#x509_extensions =
	string_mask = utf8only
	utf8 = yes
	prompt = no

[ smime_user_dn ]

	commonName=${test_commonName}

[ subject_alt_name ]

	email.0=${test_email}
	${test_email2}

[ x509_smime_rsa_user_SE_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,digitalSignature,keyEncipherment
	extendedKeyUsage = clientAuth,emailProtection
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_rsa_user_E_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,keyEncipherment
	extendedKeyUsage = emailProtection,1.3.6.1.4.1.311.80.1
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_rsa_user_S_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,digitalSignature
	extendedKeyUsage = clientAuth,emailProtection,codeSigning
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_ec_user_SE_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,digitalSignature,keyAgreement
	extendedKeyUsage = clientAuth,emailProtection
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_ec_user_E_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,keyAgreement
	extendedKeyUsage = emailProtection
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_edwards_user_E_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,keyAgreement
	extendedKeyUsage = emailProtection
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

[ x509_smime_edwards_user_S_ext ]

	basicConstraints = critical,CA:FALSE
	keyUsage = critical,digitalSignature
	extendedKeyUsage = clientAuth,emailProtection
	authorityKeyIdentifier = keyid:always
	#subjectKeyIdentifier = hash
		# ↖ standard rfc-sha1
	subjectKeyIdentifier = ${user_PublicKey_shake256xof32}
	subjectAltName = @subject_alt_name
	crlDistributionPoints=URI:${my_ca_website}/crl/${ca_serial_number}.der.crl

### END SMIME USER x509v3_config
EOF
}


csr_user_RSA1024 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA1024.pem")
EOF
}

csr_user_RSA2048 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA2048.pem")
EOF
}

csr_user_RSA2048_encrypt () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA2048_encrypt.pem")
EOF
}

csr_user_RSA2048_sign () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA2048_sign.pem")
EOF
}

csr_user_RSA2048_4 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA2048_4.pem")
EOF
}

csr_user_RSA4096 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_RSA4096.pem")
EOF
}

csr_user_prime256v1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_prime256v1.pem")
EOF
}

csr_user_secp384r1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_secp384r1.pem")
EOF
}

csr_user_secp384r1_encrypt () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_secp384r1_encrypt.pem")
EOF
}

csr_user_secp521r1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_secp521r1.pem")
EOF
}

csr_user_ed25519 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_ed25519.pem")
EOF
}

csr_user_ed25519_2 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_ed25519_2.pem")
EOF
}

csr_user_ed448 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_ed448.pem")
EOF
}

csr_user_ed448_2 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_ed448_2.pem")
EOF
}

csr_user_brainpoolP256r1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_brainpoolP256r1.pem")
EOF
}

csr_user_brainpoolP384r1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_brainpoolP384r1.pem")
EOF
}

csr_user_brainpoolP512r1 () {
cat <<EOF
$(openssl req -new -config <(echo "$(x509v3_config_user)") -key "private/${user_alias}/key_user_brainpoolP512r1.pem")
EOF
}


# https://priyom.org/number-stations/other/v10
# Anna, Berta, Carlo, Danielle, Emelle, Figaro, Hipolit, Ida, Jacob, Kilo,
# Leopold, Marta, Nicola, Olga,
# Philip, Pietro, Quasi, Rosa, Softi, Tiodo, Ulrike, Victor, Willi, Xavier, Yvonne.

test_email2=""

# RSA 1024
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA1024.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Anna rsa1024"
test_email="anna@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x2b70cf78bd98e9fb" -in <(echo "$(csr_user_RSA1024)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_SE_ext > "private/${user_alias}/cert_user_RSA1024.crt"

# RSA 2048
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA2048.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Berta rsa2048"
test_email="berta@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x3f878f8f4fbf5c3f" -in <(echo "$(csr_user_RSA2048)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_SE_ext > "private/${user_alias}/cert_user_RSA2048.crt"

# RSA RSA2048_encrypt
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA2048_encrypt.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Berta rsa2048 Encrypt only"
test_email="berta@example.com"
test_email2="email.1=berta-encrypt@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x3be73493c1551ba8" -in <(echo "$(csr_user_RSA2048_encrypt)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_E_ext > "private/${user_alias}/cert_user_RSA2048_encrypt.crt"

# RSA RSA2048_sign
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA2048_sign.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Berta rsa2048 Sign only"
test_email="berta@example.com"
test_email2="email.1=berta-sign@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x32be5cceb33ff0b0" -in <(echo "$(csr_user_RSA2048_sign)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_S_ext > "private/${user_alias}/cert_user_RSA2048_sign.crt"

test_email2=""

# RSA RSA2048_4
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA2048_4.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Carlo rsa2048 hashAlgo rsaPSS"
test_email="carlo@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x43d43119f1301332" -in <(echo "$(csr_user_RSA2048_4)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_SE_ext -sigopt rsa_padding_mode:pss -sha256 -sigopt rsa_mgf1_md:sha256 -sigopt rsa_pss_saltlen:32 > "private/${user_alias}/cert_user_RSA2048_4.crt"

# RSA 4096
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_RSA4096.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Danielle rsa4096"
test_email="danielle@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x529888b20232f48c" -in <(echo "$(csr_user_RSA4096)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_rsa_user_SE_ext > "private/${user_alias}/cert_user_RSA4096.crt"

# prime256v1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_prime256v1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Emelle prime256v1"
test_email="emelle@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x6e6795c790a0b7ab" -in <(echo "$(csr_user_prime256v1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_prime256v1.crt"

# secp384r1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_secp384r1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Figaro secp384r1"
test_email="figaro@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x7a56afa9c2f114e3" -in <(echo "$(csr_user_secp384r1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_secp384r1.crt"

# secp384r1_encrypt
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_secp384r1_encrypt.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Gustav secp384r1 Encrypt only"
test_email="gustav@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x1a21e5ea4c064b4f" -in <(echo "$(csr_user_secp384r1_encrypt)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_E_ext > "private/${user_alias}/cert_user_secp384r1_encrypt.crt"

# secp521r1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_secp521r1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Hipolit secp521r1"
test_email="hipolit@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x20f074eed9c23d56" -in <(echo "$(csr_user_secp521r1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_secp521r1.crt"

# ed25519
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_ed25519.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Ida ed25519"
test_email="ida@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x39e1f187e33eeb83" -in <(echo "$(csr_user_ed25519)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_S_ext > "private/${user_alias}/cert_user_ed25519.crt"

# x25519
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_x25519.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Ida x25519"
test_email="ida@example.com"
read -r -d '' x25519_pub <<EOF
$(openssl pkey -pubout -outform PEM -in "private/${user_alias}/key_user_x25519.pem")
EOF
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x3447f1de8400d19a" -in <(echo "$(csr_user_ed25519)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -force_pubkey <(echo "${x25519_pub}") -keyform PEM -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_E_ext > "private/${user_alias}/cert_user_x25519.crt"

# ed448
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_ed448.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Jacob ed448"
test_email="jacob@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x47f663ce02cb7e71" -in <(echo "$(csr_user_ed448)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_S_ext > "private/${user_alias}/cert_user_ed448.crt"

# x448
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_x448.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Jacob x448"
test_email="jacob@example.com"
read -r -d '' x448_pub <<EOF
$(openssl pkey -pubout -outform PEM -in "private/${user_alias}/key_user_x448.pem")
EOF
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x429fc54c6a30f658" -in <(echo "$(csr_user_ed448)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -force_pubkey <(echo "${x448_pub}") -keyform PEM -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_E_ext > "private/${user_alias}/cert_user_x448.crt"

# ed25519_2
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_ed25519_2.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Kilo ed25519"
test_email="kilo@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x5724c065334cfa7a" -in <(echo "$(csr_user_ed25519_2)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_S_ext > "private/${user_alias}/cert_user_ed25519_2.crt"

# x25519_2
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_x25519_2.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Kilo x25519"
test_email="kilo@example.com"
read -r -d '' x25519_pub <<EOF
$(openssl pkey -pubout -outform PEM -in "private/${user_alias}/key_user_x25519_2.pem")
EOF
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x5042881c7b74151f" -in <(echo "$(csr_user_ed25519_2)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -force_pubkey <(echo "${x25519_pub}") -keyform PEM -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_E_ext > "private/${user_alias}/cert_user_x25519_2.crt"

# ed448_2
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_ed448_2.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Leopold ed448"
test_email="leopold@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x66a9e7ac6c86349b" -in <(echo "$(csr_user_ed448_2)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_S_ext > "private/${user_alias}/cert_user_ed448_2.crt"

# x448_2
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_x448_2.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Leopold x448"
test_email="leopold@example.com"
read -r -d '' x448_pub <<EOF
$(openssl pkey -pubout -outform PEM -in "private/${user_alias}/key_user_x448_2.pem")
EOF
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -set_serial "0x652e92e41c1a9292" -in <(echo "$(csr_user_ed448_2)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -force_pubkey <(echo "${x448_pub}") -keyform PEM -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_edwards_user_E_ext > "private/${user_alias}/cert_user_x448_2.crt"

# brainpoolP256r1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_brainpoolP256r1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Marta brainpoolP256r1"
test_email="marta@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x7205ccfc61c0a8e7" -in <(echo "$(csr_user_brainpoolP256r1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_brainpoolP256r1.crt"

# brainpoolP384r1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_brainpoolP384r1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Nicola brainpoolP384r1"
test_email="nicola@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x17319e5a82b31953" -in <(echo "$(csr_user_brainpoolP384r1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_brainpoolP384r1.crt"

# brainpoolP512r1
user_PublicKey_shake256xof32="$(openssl pkey -pubout -outform DER -in "private/${user_alias}/key_user_brainpoolP512r1.pem" | openssl dgst -shake256 | awk -F '=[[:blank:]]' '{print $NF}')"
test_commonName="Olga brainpoolP512r1"
test_email="olga@example.com"
faketime "${date_base}" openssl x509 -req -days "${user_usage_period_days}" -sha256 -set_serial "0x2d2ed7a865009d34" -in <(echo "$(csr_user_brainpoolP512r1)") -CA "private/root/cert_root.crt" -CAkey "private/root/key_root.pem" -extfile <(echo "$(x509v3_config_user)") -extensions x509_smime_ec_user_SE_ext > "private/${user_alias}/cert_user_brainpoolP512r1.crt"


{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA1024.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA1024.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA2048.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA2048.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA2048_encrypt.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA2048_sign.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA2048_4.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_RSA4096.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_RSA4096.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_prime256v1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_prime256v1.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_secp384r1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_secp384r1.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_secp384r1_encrypt.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_secp521r1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_secp521r1.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_ed25519.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_ed25519.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_x25519.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_x25519.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_ed448.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_ed448.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_x448.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_x448.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_ed25519_2.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_ed25519_2.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_x25519_2.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_x25519_2.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_ed448_2.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_ed448_2.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_x448_2.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_x448_2.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_brainpoolP256r1.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_brainpoolP384r1.crt.txt"
{
	openssl x509 -purpose -text -noout -fingerprint -md5 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha1 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha256 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha384 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha512 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha3-256 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha3-384 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -sha3-512 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -shake128 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -noout -fingerprint -shake256 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
} | awk '{ sub(/[ \t]+$/, ""); print }' > "private/${user_alias}/cert_user_brainpoolP512r1.crt.txt"


openssl x509 -outform DER -in "private/root/cert_root.crt" -out "public_${user_alias}/root.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA1024.crt" -out "public_${user_alias}/user_RSA1024.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA2048.crt" -out "public_${user_alias}/user_RSA2048.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt" -out "public_${user_alias}/user_RSA2048_encrypt.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA2048_sign.crt" -out "public_${user_alias}/user_RSA2048_sign.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA2048_4.crt" -out "public_${user_alias}/user_RSA2048_4.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_RSA4096.crt" -out "public_${user_alias}/user_RSA4096.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_prime256v1.crt" -out "public_${user_alias}/user_prime256v1.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_secp384r1.crt" -out "public_${user_alias}/user_secp384r1.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt" -out "public_${user_alias}/user_secp384r1_encrypt.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_secp521r1.crt" -out "public_${user_alias}/user_secp521r1.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_ed25519.crt" -out "public_${user_alias}/user_ed25519.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_x25519.crt" -out "public_${user_alias}/user_x25519.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_ed448.crt" -out "public_${user_alias}/user_ed448.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_x448.crt" -out "public_${user_alias}/user_x448.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_ed25519_2.crt" -out "public_${user_alias}/user_ed25519_2.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_x25519_2.crt" -out "public_${user_alias}/user_x25519_2.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_ed448_2.crt" -out "public_${user_alias}/user_ed448_2.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_x448_2.crt" -out "public_${user_alias}/user_x448_2.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_brainpoolP256r1.crt" -out "public_${user_alias}/user_brainpoolP256r1.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_brainpoolP384r1.crt" -out "public_${user_alias}/user_brainpoolP384r1.cer"
openssl x509 -outform DER -in "private/${user_alias}/cert_user_brainpoolP512r1.crt" -out "public_${user_alias}/user_brainpoolP512r1.cer"

mkdir "private/credentials"

echo "password" > "private/credentials/credential_private_password.txt"

{
	openssl pkey -in "private/${user_alias}/key_user_RSA1024.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA1024.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Anna.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_RSA2048.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA2048.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Berta.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_RSA2048_encrypt.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA2048_encrypt.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Berta_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_RSA2048_sign.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA2048_sign.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Berta_S.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_RSA2048_4.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA2048_4.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Carlo.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_RSA4096.pem"
	openssl x509 -in "private/${user_alias}/cert_user_RSA4096.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Danielle.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_prime256v1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_prime256v1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Emelle.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_secp384r1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_secp384r1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Figaro.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_secp384r1_encrypt.pem"
	openssl x509 -in "private/${user_alias}/cert_user_secp384r1_encrypt.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Gustav_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_secp521r1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_secp521r1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Hipolit.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_ed25519.pem"
	openssl x509 -in "private/${user_alias}/cert_user_ed25519.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Ida_S.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_x25519.pem"
	openssl x509 -in "private/${user_alias}/cert_user_x25519.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Ida_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_ed448.pem"
	openssl x509 -in "private/${user_alias}/cert_user_ed448.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Jacob_S.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_x448.pem"
	openssl x509 -in "private/${user_alias}/cert_user_x448.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Jacob_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_ed25519_2.pem"
	openssl x509 -in "private/${user_alias}/cert_user_ed25519_2.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Kilo_S.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_x25519_2.pem"
	openssl x509 -in "private/${user_alias}/cert_user_x25519_2.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Kilo_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_ed448_2.pem"
	openssl x509 -in "private/${user_alias}/cert_user_ed448_2.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Leopold_S.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_x448_2.pem"
	openssl x509 -in "private/${user_alias}/cert_user_x448_2.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Leopold_E.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_brainpoolP256r1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_brainpoolP256r1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Marta.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_brainpoolP384r1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_brainpoolP384r1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Nicola.pem"
{
	openssl pkey -in "private/${user_alias}/key_user_brainpoolP512r1.pem"
	openssl x509 -in "private/${user_alias}/cert_user_brainpoolP512r1.crt"
	openssl x509 -in "private/root/cert_root.crt"
} > "private/credentials/credential_private_unencrypted_Olga.pem"


openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Anna.pem" -out "private/credentials/credential_private_encrypted_Anna.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Berta.pem" -out "private/credentials/credential_private_encrypted_Berta.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Berta_E.pem" -out "private/credentials/credential_private_encrypted_Berta_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Berta_S.pem" -out "private/credentials/credential_private_encrypted_Berta_S.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Carlo.pem" -out "private/credentials/credential_private_encrypted_Carlo.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Danielle.pem" -out "private/credentials/credential_private_encrypted_Danielle.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Emelle.pem" -out "private/credentials/credential_private_encrypted_Emelle.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Figaro.pem" -out "private/credentials/credential_private_encrypted_Figaro.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Gustav_E.pem" -out "private/credentials/credential_private_encrypted_Gustav_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Hipolit.pem" -out "private/credentials/credential_private_encrypted_Hipolit.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Ida_S.pem" -out "private/credentials/credential_private_encrypted_Ida_S.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Ida_E.pem" -out "private/credentials/credential_private_encrypted_Ida_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Jacob_S.pem" -out "private/credentials/credential_private_encrypted_Jacob_S.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Jacob_E.pem" -out "private/credentials/credential_private_encrypted_Jacob_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Kilo_S.pem" -out "private/credentials/credential_private_encrypted_Kilo_S.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Kilo_E.pem" -out "private/credentials/credential_private_encrypted_Kilo_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Leopold_S.pem" -out "private/credentials/credential_private_encrypted_Leopold_S.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Leopold_E.pem" -out "private/credentials/credential_private_encrypted_Leopold_E.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Marta.pem" -out "private/credentials/credential_private_encrypted_Marta.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Nicola.pem" -out "private/credentials/credential_private_encrypted_Nicola.p12" -passout file:"private/credentials/credential_private_password.txt"
openssl pkcs12 -export -certpbe PBE-SHA1-3DES -keypbe PBE-SHA1-3DES -macalg sha1 -in "private/credentials/credential_private_unencrypted_Olga.pem" -out "private/credentials/credential_private_encrypted_Olga.p12" -passout file:"private/credentials/credential_private_password.txt"


################
#
# Creates empty CRL (no entry)
#
################

touch "private/root/crl_index.txt"
echo "010000" > "private/root/crl_number.txt"

cat <<- EOF > "private/root/config_ca_revocation.cfg"
### BEGIN SMIME CA minimal CRL x509v3_config

[ ca ]

	default_ca = root_revocation_list

[ root_revocation_list ]

	database = ./private/root/crl_index.txt
	crlnumber = ./private/root/crl_number.txt

	default_crl_days = ${user_usage_period_days}
	crl_extensions = CRL_extension
	default_md = sha256

[ CRL_extension ]

	authorityKeyIdentifier = keyid:always

### END SMIME CA minimal CRL x509v3_config
EOF

OPENSSL_CONF="private/root/config_ca_revocation.cfg"

faketime "${date_base}" openssl ca -config "${OPENSSL_CONF}" -gencrl -cert "private/root/cert_root.crt" -keyfile "private/root/key_root.pem" -out "private/root/${ca_serial_number}.pem.crl"

openssl crl -text -noout -in "private/root/${ca_serial_number}.pem.crl" | awk '{ sub(/[ \t]+$/, ""); print }' > "private/root/${ca_serial_number}.pem.crl.txt"

openssl crl -outform DER -in "private/root/${ca_serial_number}.pem.crl" -out "public_${user_alias}/${ca_serial_number}.der.crl"


openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_RSA1024.crt" -out "public_${user_alias}/credential_public_Anna.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_RSA2048.crt" -out "public_${user_alias}/credential_public_Berta.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_RSA2048_encrypt.crt" -certfile "private/${user_alias}/cert_user_RSA2048_sign.crt" -out "public_${user_alias}/credential_public_Berta_E_plus_S.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_RSA2048_4.crt" -out "public_${user_alias}/credential_public_Carlo.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_RSA4096.crt" -out "public_${user_alias}/credential_public_Danielle.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_prime256v1.crt" -out "public_${user_alias}/credential_public_Emelle.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_secp384r1.crt" -out "public_${user_alias}/credential_public_Figaro.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_secp384r1_encrypt.crt" -out "public_${user_alias}/credential_public_Gustav_E.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_secp521r1.crt" -out "public_${user_alias}/credential_public_Hipolit.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_ed25519.crt" -certfile "private/${user_alias}/cert_user_x25519.crt" -out "public_${user_alias}/credential_public_Ida.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_ed448.crt" -certfile "private/${user_alias}/cert_user_x448.crt" -out "public_${user_alias}/credential_public_Jacob.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_ed25519_2.crt" -certfile "private/${user_alias}/cert_user_x25519_2.crt" -out "public_${user_alias}/credential_public_Kilo.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_ed448_2.crt" -certfile "private/${user_alias}/cert_user_x448_2.crt" -out "public_${user_alias}/credential_public_Leopold.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_brainpoolP256r1.crt" -out "public_${user_alias}/credential_public_Marta.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_brainpoolP384r1.crt" -out "public_${user_alias}/credential_public_Nicola.p7c"
openssl crl2pkcs7 -outform DER -in "private/root/${ca_serial_number}.pem.crl" -certfile "private/root/cert_root.crt" -certfile "private/${user_alias}/cert_user_brainpoolP512r1.crt" -out "public_${user_alias}/credential_public_Olga.p7c"


cat <<EOF > "checksums.md5"
$(find . -type f -exec md5sum {} \; | sort -k 2)
EOF

cat <<EOF > "checksums.sha1"
$(find . -type f -exec sha1sum {} \; | sort -k 2)
EOF

cat <<EOF > "checksums.sha224"
$(find . -type f -exec sha224sum {} \; | sort -k 2)
EOF

cat <<EOF > "checksums.sha256"
$(find . -type f -exec sha256sum {} \; | sort -k 2)
EOF

cat <<EOF > "checksums.sha384"
$(find . -type f -exec sha384sum {} \; | sort -k 2)
EOF

cat <<EOF > "checksums.sha512"
$(find . -type f -exec sha512sum {} \; | sort -k 2)
EOF

# EOF
